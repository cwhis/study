<?php
echo "<script type='text/javascript'>";
echo "Rico.acceptLanguage('" . $_SERVER["HTTP_ACCEPT_LANGUAGE"] . "');";
echo "</script>";
?>
