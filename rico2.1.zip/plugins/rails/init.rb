ActionView::Base.send :include, RicoTagHelper

ActionController::Base.send :include, RicoLiveGrid
